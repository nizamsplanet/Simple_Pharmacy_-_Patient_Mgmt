Hello


Enjoy the Simple_Pharmacy_&_Patient_Mgmt_v2024.07 app. 

pharmacy13.sqlite3 is the backend database server
Server.exe is the application+web server
FrontEnd_Client.exe is the client/thin/browser
FrontEnd_Browser.url is shortcut for your default browser on 8080

* you can also use any web browser and reach to http://localhost:8080 after the server.exe console is started
* all are bundled, including runtime, library, framework dll etc.
* .html are the template files
* .css/js are from respective contributors, thanks to picocss, stackoverflow, svfiltable, vanilla js
* built using python3.12, Bottle, Peewee, SQlite, waitress, Chatgpt, golang edge-webview2 & pyinstaller

Thanks
Nizam
Madurai.19